#include <stdio.h>

#define FRAMES 10
#define MAXROLLS 21
#define MONTHS 12

typedef struct 
{
    
};
