#include<time.h>
#include <mysql.h>

conn initMYSQL(MYSQL)
