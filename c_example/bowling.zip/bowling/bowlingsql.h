#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mysql.h>


typedef struct 
{
    int ID;
    char username[40];
    play_date varchar(40);

}bowling;
