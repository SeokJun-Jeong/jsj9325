module_var_a = "a모듈의 변수"

def module_a_func():
    print("a 모듈의 함수가 실행")