from .modulea import module_a_func, module_var_a
from .moduleb import module_var_b, Module_B

__all__ = ["module_a_func", "module_var_a", "Module_B", "module_var_b"]

def package_func():
    print("이것은 패키지에 정의된 함수")
    
print("패키지 불러옴")

def main():
    print(module_var_a)
    module_a_func()
    print(module_var_b)
    print(Module_B())
    print(module_var_a)
    package_func()
    
if __name__ == "__main__":
    main()