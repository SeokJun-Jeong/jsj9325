module_var_b = "b모듈의 변수"

class Module_B:
    def __str__(self):
        return "Module B의 객체 생성"